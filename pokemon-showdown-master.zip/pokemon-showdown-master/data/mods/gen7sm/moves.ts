export const Moves: {[k: string]: ModdedMoveData} = {
	mindblown: {
		inherit: true,
		isNonstandard: "Future",
	},
	photongeyser: {
		inherit: true,
		isNonstandard: "Future",
	},
	plasmafists: {
		inherit: true,
		isNonstandard: "Future",
	},
};
